package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String username = request.getParameter("username").trim();
        String password = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String passwordHash = DBUtil.hashPassword(password);

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT id FROM users WHERE username = ? AND password_hash = ?");
            ps.setString(1, username);
            ps.setString(2, passwordHash);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                HttpSession session = request.getSession(true);
                session.setAttribute("user", username);
                // session timeout (optional) - 30 minutes
                session.setMaxInactiveInterval(30*60);
                response.sendRedirect("dashboard.jsp");
            } else {
                out.println("<html><body style='font-family:Arial;'>");
                out.println("<h2 style='color:red;'>Invalid Username or Password</h2>");
                out.println("<a href='login.html'>Try Again</a>");
                out.println("</body></html>");
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<html><body>");
            out.println("<h3 style='color:red;'>Database error: " + e.getMessage() + "</h3>");
            out.println("<a href='login.html'>Try Again</a>");
            out.println("</body></html>");
        }
    }
}
