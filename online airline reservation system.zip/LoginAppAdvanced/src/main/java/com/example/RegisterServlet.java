package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String username = request.getParameter("username").trim();
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirm = request.getParameter("confirm_password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (!password.equals(confirm)) {
            out.println("<html><body>");
            out.println("<h3 style='color:red;'>Passwords do not match.</h3>");
            out.println("<a href='register.html'>Try Again</a>");
            out.println("</body></html>");
            return;
        }

        String passwordHash = DBUtil.hashPassword(password);

        try (Connection conn = DBUtil.getConnection()) {
            // Check existing user
            PreparedStatement check = conn.prepareStatement("SELECT id FROM users WHERE username = ?");
            check.setString(1, username);
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                out.println("<html><body>");
                out.println("<h3 style='color:red;'>Username already taken.</h3>");
                out.println("<a href='register.html'>Try Again</a>");
                out.println("</body></html>");
                return;
            }
            rs.close();
            check.close();

            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, passwordHash);
            int inserted = ps.executeUpdate();
            ps.close();

            if (inserted > 0) {
                out.println("<html><body>");
                out.println("<h3>Registration successful!</h3>");
                out.println("<a href='login.html'>Proceed to Login</a>");
                out.println("</body></html>");
            } else {
                out.println("<html><body>");
                out.println("<h3 style='color:red;'>Registration failed. Please try again.</h3>");
                out.println("<a href='register.html'>Try Again</a>");
                out.println("</body></html>");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<html><body>");
            out.println("<h3 style='color:red;'>Database error: " + e.getMessage() + "</h3>");
            out.println("<a href='register.html'>Try Again</a>");
            out.println("</body></html>");
        }
    }
}
