# LoginAppAdvanced

This project implements:
- Registration (register.html -> RegisterServlet)
- Login (login.html -> LoginServlet)
- MySQL database for storing users
- Password hashing (SHA-256)
- Session-based login & dashboard
- Logout (LogoutServlet)

## Setup

1. Install MySQL and create a database and table (see `sql/create_db.sql`).

2. Update database connection settings in `src/main/java/com/example/DBUtil.java`:
   - DB_URL, DB_USER, DB_PASSWORD

3. Add MySQL Connector/J (e.g. `mysql-connector-java-8.0.x.jar`) to `WEB-INF/lib/` or your servlet container's lib.

4. Build and deploy the WAR to Apache Tomcat (or any Java web server).

5. Access:
   - Registration: `http://localhost:8080/LoginAppAdvanced/register.html`
   - Login: `http://localhost:8080/LoginAppAdvanced/login.html`

## Notes

- Passwords are hashed with SHA-256 before storing.
- For production, use stronger password hashing (BCrypt/PBKDF2) and HTTPS.
